file(GLOB SRC CONFIGURE_DEPENDS "src/*.cpp")

add_library(blitz OBJECT ${SRC})

target_include_directories(blitz PUBLIC ${CMAKE_CURRENT_SOURCE_DIR})
set_target_properties(blitz PROPERTIES POSITION_INDEPENDENT_CODE ON)